# -*- coding: utf-8 -*-
"""
Created on Tue Aug 28 00:35:47 2018

@author: user
"""

print(help(cv2.face))